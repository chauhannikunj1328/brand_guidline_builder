Rectio vendor-lockups assets v2.2.0
Naming and usage: see 10-assets-and-naming.md in the brand docs.
