Replace this file with your real brand asset package.
